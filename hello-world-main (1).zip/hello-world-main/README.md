# hello-world
for uni use event driven programming lab.
my name is mohammad ali but i am most known as mali.
